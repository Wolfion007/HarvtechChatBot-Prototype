
public class BisonProperties {

    public static String modelProperties(String properties) {
        properties = "gyyy";
        return properties;
        
    }

    public static void main(String[] args) { //main and reference method of this class
        String s1 = ""; // Initialize s1 before passing it to ModelProperties
        String s = modelProperties(s1);
        System.out.println(s); // Print or use the result as needed
    }
}