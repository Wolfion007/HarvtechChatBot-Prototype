
public class BisonLocation {

	
	public static String bisonLoc(String bloc){
		bloc="";
		return bloc;
	}
	
	
	public static void main(String[] args) {
		
		String b="";
		String bl= bisonLoc(b);
		System.out.println(bl);
		
	}
}
