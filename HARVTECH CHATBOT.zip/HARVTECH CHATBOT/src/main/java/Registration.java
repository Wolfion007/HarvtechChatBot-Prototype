import java.util.Scanner;

public class Registration extends BotFunctions {
	
	static  String registerId;
	static String Name;
	static String aadharNumber;
	

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		registerId=sc.next();
		Name=sc.next();
		aadharNumber=sc.next();
		
		
	}

}
